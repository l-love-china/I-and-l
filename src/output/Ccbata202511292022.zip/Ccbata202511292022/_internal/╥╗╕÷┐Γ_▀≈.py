def 输入(内容):
    return input(内容)

def 打开(路径, 方式):
    return open(路径, 方式, encoding="utf-8")  # 建议加上编码  喵~

def 读取(操作):
    return 操作.read()
def 关闭(操作):
    操作.close()
def 分行拆分(原始文本: str) -> list[list[str]]:
    """
    把一段用换行符分隔的文本变成二维列表：
    一行一个内层列表，每个空格拆分一次，空行自动跳过。
    """
    return [行.split() for 行 in 原始文本.splitlines() if 行.strip()]
def 打印(内容):
    print(内容)
def 等于吗(值1, 值2):
    return 值1 == 值2
def 打开_读取():
    return "r" #看起来让中文更多github的老外看不懂  喵~
def 打开_写入():
    return "w"
def 打开_追加():
    return "a"
def 求长度(内容):
    return len(内容) #求长度 喵~
def 写入(操作, 内容):
    操作.write(内容)